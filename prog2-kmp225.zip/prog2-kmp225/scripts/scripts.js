document.addEventListener('DOMContentLoaded', function() { //I had to change it back to DOMContentLoaded (?) in order to make the code work
    var table = document.getElementById('puzzle');
    
    table.addEventListener('click', function(clicked) {
        var selectedCell = clicked.target;
        if (selectedCell.tagName === 'TD') {
            swap(selectedCell);
        }
    });
    
    scram.addEventListener('click', function(){
        scramblePuzzle();
    });


    reset.addEventListener('click', function() {
        resetPuzzle();
    });
});


// Swap contents to fill blank cell
function swap(selectedCell) {
    var blankCell = document.querySelector('td:empty'); // Finds blank cell
    blankCell.classList.remove('blank');
    selectedCell.classList.add('blank');
    blankCell.textContent = selectedCell.textContent;
    selectedCell.textContent = '';
    
    if (isAdjacent(selectedCell, blankCell)) {
        // Swap the contents
        blankCell.textContent = selectedCell.textContent;
        selectedCell.textContent = '';
    }

    isSolved();
}


/* 
isAdjacent() was not working properly and I could not figure out how to fix it in time
-->add a function to check adjacent cells, use coordinates of blank cell to swap cells
-->write code check once in two different places - once in swap when you click on a cell and once in scramble when you check adjacent cells

function isAdjacent(cell) {
    const parentRow = cell.parentElement;
    const rowIndex = parentRow.rowIndex;
    const cellIndex = cell.cellIndex;
    const adjacentCells = [];
  
    //Go up one row = row - 1
    if (parentRow.previousElementSibling) {
      adjacentCells.push(parentRow.previousElementSibling.cells[cellIndex]); 
    }
    //Go down one row = row + 1
    if (parentRow.nextElementSibling) {
      adjacentCells.push(parentRow.nextElementSibling.cells[cellIndex]); 
    }
    // Left = cell - 1
    if (parentRow.cells[cellIndex - 1]) {
      adjacentCells.push(parentRow.cells[cellIndex - 1]);
    }
    // Right = cell + 1
    if (parentRow.cells[cellIndex + 1]) {
      adjacentCells.push(parentRow.cells[cellIndex + 1]);
    }
  
    return adjacentCells;
  }
*/


//Scramble button
function scramblePuzzle(selectedCell){

        const cell1 = document.getElementById('cell1');
        const cell2 = document.getElementById('cell2');
        const cell3 = document.getElementById('cell3');
        const cell4 = document.getElementById('cell4');
        const cell5 = document.getElementById('cell5');
        const cell6 = document.getElementById('cell6');
        const cell7 = document.getElementById('cell7');
        const cell8 = document.getElementById('cell8');
        const cell9 = document.getElementById('cell9');
        const cell10 = document.getElementById('cell10');
        const cell11 = document.getElementById('cell11');
        const cell12 = document.getElementById('cell12');
        const cell13 = document.getElementById('cell13');
        const cell14 = document.getElementById('cell14');
        const cell15 = document.getElementById('cell15');
        const blankCell = document.getElementById('blankCell');
    
        cell1.textContent = '9';
        cell2.textContent = '15';
        cell3.textContent = '7';
        cell4.textContent = '5';
        cell5.textContent = '14';
        cell6.textContent = '2';
        cell7.textContent = '13';
        cell8.textContent = '6';
        cell9.textContent = '10';
        cell10.textContent = '4';
        cell11.textContent = '';
        cell12.textContent = '1';
        cell13.textContent = '11';
        cell14.textContent = '3';
        cell15.textContent = '12';
        blankCell.textContent = '8';
}


//Change background color when solved --> cannot get to work
function ifSolved() {
  var table = document.getElementById('puzzle');
  var correctOrder = 1;
  var isSolved = true;

  for (var row = 0; row < table.rows.length; row++) {
    for (var cell = 0; cell < table.rows[row].cells.length; cell++) {
      var cellText = table.rows[row].cells[cell].innerText.trim();

      // Check if the current cell is the last cell (bottom right)
      if (row === table.rows.length - 1 && cell === table.rows[row].cells.length - 1) {
        if (cellText !== '') { // If the last cell is not blank, the puzzle is not solved
          isSolved = false;
        }
      } else {
        if (parseInt(cellText) !== correctOrder) { // Check if numbers are in the correct order
          isSolved = false;
        }
        correctOrder++; // Move on to the next number
      }

      if (!isSolved) break; // Exit the loop early if any condition for being solved isn't met
    }

    if (!isSolved) break; // Exit the outer loop early if not solved
  }
  if (isSolved) {
    table.style.backgroundColor = 'red';
  }
}


//Reset button
//This was the only way I could figure out how to do this– I'm sure there are definitely simpler ways.
function resetPuzzle(){
    const cell1 = document.getElementById('cell1');
    const cell2 = document.getElementById('cell2');
    const cell3 = document.getElementById('cell3');
    const cell4 = document.getElementById('cell4');
    const cell5 = document.getElementById('cell5');
    const cell6 = document.getElementById('cell6');
    const cell7 = document.getElementById('cell7');
    const cell8 = document.getElementById('cell8');
    const cell9 = document.getElementById('cell9');
    const cell10 = document.getElementById('cell10');
    const cell11 = document.getElementById('cell11');
    const cell12 = document.getElementById('cell12');
    const cell13 = document.getElementById('cell13');
    const cell14 = document.getElementById('cell14');
    const cell15 = document.getElementById('cell15');
    const blankCell = document.getElementById('blankCell');

    cell1.textContent = '1';
    cell2.textContent = '2';
    cell3.textContent = '3';
    cell4.textContent = '4';
    cell5.textContent = '5';
    cell6.textContent = '6';
    cell7.textContent = '7';
    cell8.textContent = '8';
    cell9.textContent = '9';
    cell10.textContent = '10';
    cell11.textContent = '11';
    cell12.textContent = '12';
    cell13.textContent = '13';
    cell14.textContent = '14';
    cell15.textContent = '15';
    blankCell.textContent = '';
    blankCell.classList.add('blank');
}

/* changeHighlight() from tablerowsmouseover.html because I thought this would be a nice touch */
function changeHighlight(evt, backgroundColor, foregroundColor) {
  var cell = evt.target;
  var row = cell; 
  row.style.backgroundColor = backgroundColor;
  row.style.color = foregroundColor;
}

function setHighlight(evt) {
  changeHighlight(evt, "blue", "white");
}

function removeHighlight(evt) {
  changeHighlight(evt, "white", "black");
}

function setup() {
var rows = document.getElementsByTagName("tbody")[0].rows;
for (var i=0; i < rows.length; ++i) {
  rows[i].onmouseover = function (evt) { setHighlight(evt) }
  rows[i].onmouseout = function (evt) { removeHighlight(evt) }
}
}

window.onload = setup;




    /*old code for swap function    
        blankCell.classList.remove('blank');
        selectedCell.classList.add('blank');
        blankCell.textContent = selectedCell.textContent;
        selectedCell.textContent = '';*/

    /*old code for scramblePuzzle()
        const num = 100;
        for (let i = 0; i < num; i++) {
                const blankCell = document.querySelector('.blank');
                const adjacentCells = getAdjacentCells(blankCell);
                const randomIndex = Math.floor(Math.random() * adjacentCells.length);
                const randomAdjacentCell = adjacentCells[randomIndex];
                swapCells(blankCell, randomAdjacentCell);
            }*/

    //window.onload = resetPuzzle; //I found this on w3schools when I was trying to figure out how to make the resetPuzzle function, so I thought I'd just include it.